package com.alibaba.otter.canal.client.adapter.support;

public class Constant {

    public static final String CONF_DIR = "conf";
}
