package com.alibaba.otter.canal.adapter.launcher.common;

public enum Mode {
                  LOCAL, // 本地模式
                  DISTRIBUTED // 分布式
}
